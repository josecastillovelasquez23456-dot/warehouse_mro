console.log("bultos.js cargado");
