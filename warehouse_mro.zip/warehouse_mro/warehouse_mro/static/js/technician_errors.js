console.log("technician_errors.js cargado");
