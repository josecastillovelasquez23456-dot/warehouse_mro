// Espacio para lógica futura de inventario
console.log("inventory.js cargado");
